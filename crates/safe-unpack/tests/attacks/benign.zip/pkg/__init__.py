# synthetic fixture
