// synthetic fixture
